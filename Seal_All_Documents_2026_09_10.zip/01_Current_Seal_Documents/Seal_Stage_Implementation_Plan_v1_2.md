# Seal 🦭 — Stage Implementation Plan

Version 1.2 | Updated 7 September 2026; first issued 5 September 2026 | Owner: Freston Kenny Adedeme

Status: implementation-planning companion to the integrated Concept and Implementation Baseline v1.6; prepared for delivery-team assignment and gate review. This document distinguishes proposed assignments, accountable roles, confirmed approvals, and unconfirmed work using the following status language:

- **Proposed assignment**: a recommended owner or action that has not yet been accepted.
- **Accountable role**: the role responsible for ensuring the work is completed; this does not confirm that a person has been appointed.
- **Confirmed approval**: an approval or decision recorded in the controlled evidence set.
- **Unconfirmed work**: work, capacity, evidence, appointment, approval or outcome not yet supported by recorded evidence.
- **Task status**: **Blocked → Ready → In progress → Review → Verified**. A task is **Verified** only when its acceptance evidence has been reviewed and recorded.

This is not a software release and does not evidence that any gate has passed.

## Executive gate-readiness summary

### Current readiness position

**Overall status: HOLD / Not gate-ready for implementation commitment, laboratory scanning, external pilot or production use.**

Seal v1.3 was adopted as the concept baseline; the owner-directed v1.6 integration is now the working document for controlled Phase 0 preparation. No formal Project Authority gate, software gate, staffing commitment, independent review, legal determination, privacy approval, external authorization, implementation result or pilot approval is confirmed by this plan.

The immediate objective is to complete Phase 0 decisions and produce a capacity-matched, independently reviewable readiness pack. Until then, all related work remains **Unconfirmed** and **Blocked** unless separately authorized for controlled preparation.

### Blockers

1. **Named governance appointments are not confirmed**: sponsor, project manager, acceptance authority and independent reviewer remain unappointed or unrecorded.
2. **Project and software classification is not confirmed**: Class A / Software Class 3 and any Class 4 escalation triggers require a signed decision.
3. **Capacity and schedule are not committed**: four engineering FTE plus legal and independent-assurance capacity must be confirmed before delivery commitment.
4. **Product and architecture baseline is not approved**: PRD, exclusions, threat model, interface contracts, fingerprinting and priority specifications remain unconfirmed.
5. **Selected second adapter is not approved**: Semgrep or dependency-only Trivy must be selected with coverage, licensing, fixture and capacity evidence.
6. **Outbound boundary and emergency stop design is not approved**: fail-closed behavior, redirect/DNS controls, request limits and worker escape tests remain open.
7. **Evidence trust model is not established**: external audit sink, key custody, retention lock, anchor failure behavior and independent administration remain unconfirmed.
8. **Privacy and evidence handling are not approved**: PIA, data inventory, processing roles, minimization, retention, access, hold and disposal controls are outstanding.
9. **Regulatory workstream has not produced determinations**: counsel engagement and written determinations for any external target or pilot remain outstanding.
10. **Operations policy is not approved**: priority, remediation, threat freshness, incident contacts, maintenance and escalation rules remain open.
11. **Independent assurance is not funded or scheduled**: QA, security, privacy, accessibility, recovery, legal and independent review must be separately resourced.
12. **No production-control implementation or acceptance evidence is confirmed here**: F01–F08, L01–L05, W01–W05, H01–H05 and O01–O04 are proposed work only.

### Required evidence before the next gate decision

The following evidence must be recorded in the controlled evidence index before Phase 0 exit and any implementation commitment:

- D01: named sponsor, project manager, acceptance authority and independent reviewer; role separation and appointment scope.
- D02: signed Project Class A / Software Class 3 classification, including Class 4 escalation triggers.
- D03: capacity-matched schedule with named weekly availability, estimates, dependencies and rebaseline approval.
- D04: approved Semgrep or Trivy selection, including coverage, licensing, fixture suitability and capacity impact.
- D05: approved PRD and architecture baseline with requirements, exclusions, threat model, contracts, fingerprinting and priority rules.
- D06: approved outbound boundary and emergency stop design, including fail-closed and escape-test evidence.
- D07: approved audit sink and key custody design, including separated administration, retention lock, signing, rotation, anchoring and failure semantics.
- D08: approved PIA and evidence-handling design, including data inventory, minimization, access, retention, hold and disposal.
- D09: counsel engagement and written regulatory workstream instruction covering the required v1.3 determinations.
- D10: approved operations policy covering priority, remediation, threat data, incidents, maintenance and escalation.
- D11: funded assurance plan with owners, effort, cost and dates.
- Phase 0 readiness pack: requirements traceability, architecture, threat model, privacy assessment, test plan, deployment plan, operations plan, capacity schedule and assurance funding.
- Gate record: signed Project Authority PM Gate 2 / software G1 decision with explicit scope, conditions, prohibited actions and expiry.

Evidence sequencing: foundation readiness and explicit owned-lab authorization precede controlled laboratory integration runs. Those runs generate adapter/G3 evidence; full workflow/hardening evidence is due before pilot acceptance, not before the integration runs that produce it. The following are progressive deliverables, not one pre-scan checklist:

- Foundation control tests F01–F08, including tenant isolation, authorization, outbound enforcement, stop control, audit integrity and evidence protection.
- G3 software evidence: code review, build provenance, component inventory, unit/integration results and known defects.
- L01–L05 adapter contracts, pinned tool/input revisions, benchmark coverage and negative fixtures.
- W01–W05 end-to-end find–fix–prove evidence with actor separation and recurrence handling.
- H01 independent assessment, H02 resilience testing, H03 compromise tabletop, H04 operational handover package and H05 signed readiness decision.
- External pilot packet, if applicable: legal determination, PIA, processing terms, target permission, scope, exclusions, contacts, limits, monitoring, stop rehearsal and retention arrangements.

### Decision-makers

|Decision area                             |Required decision-maker or authority                        |Decision required                                                                                  |
|------------------------------------------|------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
|Governance appointments and gate authority|Project Authority                                           |Appoint sponsor, project manager, acceptance authority and independent reviewer; confirm separation|
|Classification and baseline               |Project Authority                                           |Approve Project Class A / Software Class 3 and combined G1 baseline                                |
|Capacity and schedule                     |Project Authority on PM recommendation                      |Confirm staffing, availability, schedule and assurance funding                                     |
|PRD, architecture and adapter selection   |Product/security lead, subject to Project Authority approval|Approve requirements, exclusions, architecture and selected Semgrep or Trivy adapter               |
|Security boundary and emergency stop      |Security/platform leads, independently reviewed             |Approve fail-closed outbound controls, stop behavior and laboratory scope                          |
|Audit trust and key custody               |Platform lead with assurance reviewer                       |Approve sink, custody, anchoring and failure semantics                                             |
|Privacy and evidence handling             |Privacy reviewer                                            |Approve PIA, processing, retention, access, hold and disposal controls                             |
|Regulatory and external pilot conditions  |Qualified legal/compliance adviser and Project Authority    |Record determinations and approve or hold any external target activity                             |
|Operational policy and acceptance         |Security lead and service owner                             |Approve priority, remediation, incident, maintenance and support policies                          |
|Independent readiness                     |Independent reviewer                                        |Issue assessment, findings, retests and residual risk opinion                                      |
|Combined readiness decision               |Project Authority                                           |Proceed, hold or rework for the stated environment and scope                                       |
|Closure and benefits                      |Project Authority and named benefits owner                  |Approve PM Gate 6 closure and PM Gate 7 benefits review                                            |

No preparer may self-approve a gate or acceptance decision where role separation is required.

### Dependencies

The critical dependency chain is:

**D01–D03 → D05 → F01 → F02/F03 → F04 → F05 → F06/F07 → F08 → L01 → L02/L03 → L04 → L05 → W01–W05 → H01–H05 → authorized lab acceptance or separately approved pilot.**

Cross-cutting dependencies:

- D04 is required before L03 and affects fixture, licensing and capacity planning.
- D06 is required before F05 and any scanner traffic.
- D07 is required before F07 and any external trust claim.
- D08 is required before real personal data or external evidence is processed.
- D09 is required for external-target regulatory decisions and incident escalation.
- D10 is required before priority, remediation and verification workflows are accepted.
- D11 is required before commitment to assurance-dependent gates.
- Legal lead time may defer an external pilot without preventing permitted laboratory preparation.
- Laboratory acceptance does not authorize production operation or external scanning.

### Next decision date

**Next planned decision date: end of Phase 0, at the completion of Weeks 1–4, subject to confirmation by the Project Authority.**

This is a planning checkpoint, not a committed calendar date. The decision is the combined **PM Gate 2 / software G1 baseline and Phase 0 exit**. The decision pack must be submitted only when D01–D11 evidence, named capacity, the PRD and architecture baseline, and the required governance and assurance materials are complete.

**Decision options:**

- **Proceed within stated laboratory planning scope**: Phase 1 may be scheduled with accepted assignments and confirmed capacity.
- **Hold**: unresolved blockers, missing evidence, insufficient capacity or role conflicts prevent progression.
- **Rework**: revise the baseline, controls, scope or evidence pack and return for decision.

No scanner worker, external target, production environment or pilot may be activated by a Proceed decision unless that specific environment and activity are explicitly authorized in the signed gate record.

## 1. Authority and intended result

The owner adopted Seal v1.3 in the conversation on 5 September 2026. That adoption is a **confirmed owner adoption** for the concept only; formal institutional baseline approval is a separate decision. This companion translates that baseline into proposed work packages; it neither changes the concept’s approval block nor replaces the controlled concept. Formal Project Authority decisions, named independent review, capacity confirmation and the standing external-assessment conditions remain **unconfirmed** unless separately recorded. The owner-directed merge incorporates U01–U14 from the v1.4 proposal into baseline v1.6. Numerical policy candidates and runtime choices still require their named decisions; no institutional gate or implementation result is confirmed by incorporation.

The intended result is a laboratory-only find–fix–prove platform: authorized input, bounded assessment, normalized evidence, human triage, assigned correction, scoped verification and defensible closure. No deployed system, scanner integration or passing implementation test is confirmed here.

Scope: ZAP web adapter plus exactly one selected source or dependency adapter, tenant-aware data, isolated execution, evidence protection, remediation, dashboard and JSON/CSV export. Network discovery, configuration scanning, endpoint/cloud coverage, additional software adapters, production multi-organization operation, external ticket creation, product CI/CD enforcement hooks and product-generated DOCX/PDF remain deferred. Internal engineering CI is required and is distinct from the deferred product integration feature.

## 2. Schedule and decision rules

Weeks below reproduce the v1.3 planning scenario and are not committed calendar dates. Four engineering FTE plus milestone legal and independent-assurance capacity must be **confirmed before commitment**. The solo 44–52-week range is a planning alternative, not a confirmed delivery estimate. The project manager is the **accountable role** for estimating work packages against named weekly availability and rebaselining before commitment.

|Stage                                 |Planning window                                         |Entry condition                                      |Completion decision                                                                        |
|--------------------------------------|--------------------------------------------------------|-----------------------------------------------------|-------------------------------------------------------------------------------------------|
|Phase 0: decisions and requirements   |Weeks 1–4                                               |Controlled preparation adopted                       |PM Gate 1/software G0 evidence followed by Project Authority PM Gate 2/software G1 approval|
|Phase 1: platform foundation          |Weeks 5–10                                              |Phase 0 exit recorded                                |Foundation tests and integrated PM Gate 3/software G2 readiness pack                       |
|Phase 2: laboratory detection         |Weeks 11–18                                             |Foundation controls proven; G2 readiness approved    |Reviewed build and software G3 evidence before formal testing                              |
|Phase 3: find–fix–prove               |Weeks 19–23                                             |Adapter contracts and reproducible observations ready|End-to-end evidence accumulated for PM Gate 4/software G4                                  |
|Phase 4: hardening and pilot readiness|Weeks 24–28                                             |Candidate build frozen; G3 evidence complete         |Independent review and combined PM Gate 4/software G4 decision                             |
|Handover and closure                  |After authorized pilot or documented lab-only acceptance|Authorized acceptance scope and operational evidence |PM Gate 6 with software G5/G6 as applicable                                                |
|Benefits review                       |Date set at handover                                    |Named benefits owner and baseline measures           |PM Gate 7                                                                                  |

The decisions in the table are **planned decision points**, not confirmed approvals.

PM Gate 5 is recurring continuation/exception governance, not a replacement delivery phase. Raise it when scope, risk, resources, forecast or approved tolerances require a decision. Apply the Class A cadence in the governing framework. Create evidence once and reference the same pack across aligned gates.

Production authorization is not implied by laboratory acceptance. External assessment requires recorded regulatory determinations, target authorization and the relevant readiness approval. Safe-active checks remain confined to owned laboratory targets under v1.3 even if a later passive external pilot is approved. No gate may be self-approved by the preparer in breach of the role-separation rules.

## 3. Phase 0: turn open decisions into explicit inputs

All entries begin **Unconfirmed**. A role name identifies the proposed accountable role; it does not confirm that a person has been appointed or has accepted the assignment. Each item remains **Blocked** until the required decision or evidence is recorded.

|ID |Decision / artifact                                                             |Proposed accountable role            |Status and required evidence                                                                                                                                                                            |
|---|--------------------------------------------------------------------------------|-------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|D01|Appoint sponsor, project manager, acceptance authority and independent reviewer |Project Authority                    |**Unconfirmed / Blocked**. Names, separation checks, appointment scope and review period required before Phase 0 exit                                                                                   |
|D02|Confirm Project Class A / Software Class 3; document Class 4 escalation triggers|Project Authority                    |**Unconfirmed / Blocked**. Signed classification and combined G1 baseline decision required before Phase 0 exit                                                                                         |
|D03|Confirm staffing and schedule                                                   |Project manager                      |**Unconfirmed / Blocked**. Weekly allocations, task estimates, dependency/resource check and approved schedule of record required before Phase 0 exit                                                   |
|D04|Select Semgrep or Trivy                                                         |Product/security lead                |**Unconfirmed / Blocked**. One approved adapter decision; language/artifact coverage, licensing review, fixture suitability and capacity. Trivy excludes configuration scanning                         |
|D05|Baseline PRD and architecture                                                   |Product/security lead                |**Unconfirmed / Blocked**. Requirement IDs, prohibited capabilities, acceptance cases, threat model, interface contracts, fingerprint and priority specifications                                       |
|D06|Design enforced outbound boundary and emergency stop                            |Security/platform leads              |**Unconfirmed / Blocked**. Data-flow/threat model, fail-closed decisions, worker escape tests, request limits and profile approval                                                                      |
|D07|Select external audit sink and key custody                                      |Platform lead with assurance reviewer|**Unconfirmed / Blocked**. Independent administration, retention lock, signing/key rotation, anchor acknowledgment and failure behavior; no claim of external trust from a local mock                   |
|D08|Approve privacy and evidence handling                                           |Privacy reviewer                     |**Unconfirmed / Blocked**. Seal PIA, data inventory, processing roles, minimization, access, retention/hold/disposal map; required before real personal data or external evidence                       |
|D09|Start regulatory workstream                                                     |Legal/compliance adviser             |**Unconfirmed / Blocked**. Counsel engagement, written instruction covering the four v1.3 determinations, owner and evidence register in Phase 0. Final determination is a separate external-target gate|
|D10|Set operations policy                                                           |Security lead and service owner      |**Unconfirmed / Blocked**. Approved priority decision tree, validation/remediation deadlines, threat-data freshness, incident contacts, maintenance window and escalation paths                         |
|D11|Fund assurance separately                                                       |Project manager                      |**Unconfirmed / Blocked**. QA, security, privacy, accessibility, recovery, legal and independent-review effort, cost, owner and dates as a distinct G2 line item                                        |

Phase 0 exit requires the named review and Project Authority decision, no unresolved S2 design decision, confirmed allocations and an approved capacity-matched plan. These are **required approvals**, not confirmed approvals. Legal lead-time delay may defer an external pilot without preventing permitted laboratory preparation.

First five working days: the following are **proposed assignments**:

- Project manager: prepare D01–D03.
- Security lead: prepare D04–D06 and requirement traceability.
- Platform and assurance leads: prepare D07.
- Privacy and legal reviewers: begin D08–D09.
- Service owner: prepare D10.
- Project manager: draft D11.

These assignments are proposed and remain **unconfirmed** until accepted by named individuals.

## 4. Work package contract

Every package below must become a tracked task with: ID, source section, named assignee, reviewer, dependencies, estimate, acceptance test IDs, evidence link and status. Until a named assignee accepts the task, the assignment is **Proposed assignment** and the task is **Blocked**.

Use task statuses **Blocked → Ready → In progress → Review → Verified**. Failed or incomplete acceptance returns the task to **In progress**. A missing external approval remains **Blocked**. No task is **Verified** merely because its code is merged.

Common definition of done: reviewed code or controlled artifact; tenant and authorization negatives where relevant; passing repeatable tests; schema/migration compatibility check; security/privacy assessment; updated runbook; evidence tied to commit, environment and dependency versions. A reviewer records residual limitations explicitly.

## 5. Phase 1 — platform foundation

All rows below are **proposed work**. The listed owner is the proposed accountable role, not a confirmed assignee. Each package begins **Blocked** pending accepted assignment and dependencies.

|ID / proposed owner role  |Deliverable and implementation boundary                                                                                                                   |Dependencies |Acceptance evidence                                                                                                                                                         |
|--------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|F01 / QA-DevSecOps        |Versioned repository structure, pinned dependency policy, synthetic lab isolation, internal CI, secret handling and controlled build process              |D03, D05     |Fresh environment reproduces the build and tests; no committed credentials; network boundaries documented                                                                   |
|F02 / Platform            |Identity-provider integration, privileged MFA, role matrix, short-lived worker identity and revocation                                                    |F01, D05     |Assessor cannot approve own authorization; remediation owner cannot approve own closure; denied operations are audited; revoked access fails                                |
|F03 / Platform            |First migrations with organization_id, foreign-key tenant consistency, data-access tenant context and PostgreSQL RLS; separate runtime/migration roles    |F01, D05     |Positive and negative tests across reads, writes, joins, workers, caches and exports; runtime credentials cannot bypass RLS                                                 |
|F04 / Platform-security   |Target registry and versioned authorization records: ownership, exact target, exclusions, techniques, window, approver, emergency contacts and environment|F02, F03     |Missing, expired, revoked or mismatched authorization denies execution; target registration does not itself grant scan permission                                           |
|F05 / Security integration|Enforced outbound broker/boundary; approved destination resolution and redirect revalidation; deny direct worker egress                                   |F04, D06     |Controlled DNS/address changes, redirects and direct worker connections cannot escape scope; checks cover each new connection/request as appropriate, not merely submission |
|F06 / Platform            |Queue/job lifecycle, idempotency, leases, bounded retries, health controls, profile budgets and stop control                                              |F04, F05     |Duplicate delivery does not duplicate unauthorized work; cancellation is not undone by retry; restart requires renewed scope check; stop timings measured                   |
|F07 / Platform-assurance  |Transactional audit append, canonical hash chain, protected NOLOGIN seal_audit_owner, evidence-digest commitment, signed external anchors and monitoring  |F02, F03, D07|Concurrent writes preserve sequence; altered rows/artifacts and anchor failures detected; no routine role can assume owner; real separated sink verified before trust claims|
|F08 / Platform-privacy    |Sanitized encrypted evidence storage, access rules, retention/hold enforcement and disposal workflow                                                      |F03, F07, D08|Seeded tokens and personal markers removed before retained output/logs; hold prevents deletion; authorized disposal and denied download are audited                         |

Sequence F01 first; F02/F03 can overlap only after assignments and capacity are confirmed. F04 follows both; F05 precedes any scanner traffic; F06 and F07 can progress independently after their inputs. F08 requires the approved handling design. No scanner worker is admitted until scope, isolation, stop and evidence-path tests pass.

Audit implementation details to resolve in D07: append through a restricted procedure interface; revoke public execution and avoid unsafe name resolution; keep object ownership out of runtime roles; define transaction boundaries and outbox/retry handling for anchors. A successful API acknowledgment must mean the audit event is durably committed. High-risk actions require visible anchor status; the implementation must not label unanchored decisions externally verified. Pending approval anchors must not activate scan authority; revocation and emergency stop must take effect even if anchoring fails. Record these failure semantics for security review before implementation.

Foundation exit is a **planned approval condition**. F01–F08 must be reviewed; mandatory control tests must pass; and the integrated G2 pack must contain architecture, threat model, privacy assessment, test/deployment/operations plans, capacity schedule and funded assurance. Missing controls block live laboratory scanning; fixtures may still be used for permitted design work.

## 6. Phase 2 — laboratory detection MVP

All rows below are **proposed work**. The listed owner is the proposed accountable role. No adapter implementation or acceptance result is confirmed.

|ID / proposed owner role  |Deliverable and implementation boundary                                                                                                        |Dependencies |Acceptance evidence                                                                                                                                      |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|-------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
|L01 / Security integration|Versioned adapter input/output contracts and bounded parser; no user-supplied shell commands or unrestricted scanner flags                     |F01–F08, D04 |Malformed, oversized, unknown-version and cross-tenant output rejected without unsafe processing                                                         |
|L02 / Security integration|Restricted ZAP integration; passive default; reviewed target interaction profile; safe-active disabled unless exact lab/profile approval exists|L01, F05, F06|Owned lab only; no unrestricted crawler/actions; prohibited write/auth/upload classes denied; per-target limits and stop honored                         |
|L03 / Security integration|Exactly one selected Semgrep or dependency-only Trivy integration; authorized pinned input artifact                                            |L01, D04     |Exact tool/rules/input revision recorded; unselected analysis classes disabled; artifact treated as untrusted data, not executed application code        |
|L04 / Platform-security   |Normalized finding and separate observations, fingerprint versioning, reviewed aliases and reversible merge/split operations                   |L02, L03     |>=95% selected same-finding mutations retain/correctly alias identity; zero seeded distinct findings silently merged; tenant/target boundary retained    |
|L05 / QA-security         |Versioned seeded benchmark and coverage manifest; explicit negative fixtures and collection failures                                           |L02–L04      |>=90% of selected seeded baseline detected, denominators and uncovered classes reported; synthetic outputs identified separately from actual adapter runs|

Adapter result contract: schema version; organization/target/job/authorization/profile IDs; tool, rule and input revisions; start/end status; coverage and truncation indicators; source observations; sanitization outcome; evidence references. Findings contain fingerprint/version, source identity, separate severity/likelihood/action/confidence dimensions and observation links. A failed or partial scan never implies a finding is fixed.

Identity rules follow v1.3 §6.10: web identities use alert class, normalized route, method class and parameter within organization/target; source identities use rule and structural context within repository; dependency identities use ecosystem/package/vulnerability within logical artifact. Volatile line/layer/build details remain observation evidence. Dependency identity must preserve distinct deployable artifacts. Route/context ambiguities require review rather than silent merge.

Before formal testing, collect software G3 code review, build provenance, component inventory, unit/integration results and known-defect evidence. These are **required evidence items**, not confirmed evidence. No new scanner class may enter via a profile setting alone.

## 7. Phase 3 — find–fix–prove workflow

All rows below are **proposed work**. The listed owner is the proposed accountable role. Closure, verification and recurrence outcomes remain **unconfirmed** until evidence is reviewed.

|ID / proposed owner role|Deliverable and implementation boundary                                                                              |Dependencies |Acceptance evidence                                                                                                                                                          |
|------------------------|---------------------------------------------------------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|W01 / Security-platform |Separate source and environment-adjusted CVSS fields, dated EPSS, approved SSVC-style tree and independent confidence|L04, D10     |Source scores/evidence never overwritten; missing signals are unknown, not zero; severe low-confidence findings enter urgent validation; priority floor exception is explicit|
|W02 / Platform-frontend |Authorized triage, assignment, remediation, expiring suppression/exception and reviewer-owned overrides              |W01, F02, F07|Every transition checks role and organization; reason/reviewer/expiry captured; expired exceptions return to attention; accepted risk is not verified closure                |
|W03 / Security-platform |Scoped verification job, coverage comparison, independent closure and automatic recurrence handling                  |W02, L05     |Matching complete successful rescan plus reviewer decision can close; error/timeout/partial coverage cannot; unchanged finding remains open; post-closure recurrence reopens |
|W04 / Frontend          |Role-based dashboard, evidence views, management summary and tenant-filtered JSON/CSV export                         |W01–W03, F08 |Role scenarios work by keyboard; server enforces scope; CSV formula injection mitigated; downloads sanitized; deferred capabilities absent                                   |
|W05 / QA-product        |Seeded user acceptance journey and user guides                                                                       |W04          |Record authorization → discovery → triage → override → assignment → fix → verification → closure → recurrence, with anchored evidence and actor separation                   |

Verification is not simply “no alert returned.” Require the same logical target/control, a compatible recorded profile/rule set, completed collection, adequate coverage, authorized current input and a defensible comparison. Removed or inaccessible targets require explicit disposition, not automatic proof of remediation. The original observation and reviewer reasoning remain traceable.

End-to-end demonstration uses synthetic or permitted owned-lab evidence. A source/dependency example must not be presented as proof that the deployed application is unreachable or safe unless that separate condition was actually verified.

## 8. Phase 4 — hardening and pilot readiness

All rows below are **proposed work**. Independent review, readiness approval and pilot authorization are **unconfirmed** unless separately recorded.

|ID / proposed owner role  |Deliverable                                                                               |Dependencies                               |Acceptance evidence                                                                                                                                        |
|--------------------------|------------------------------------------------------------------------------------------|-------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
|H01 / Independent reviewer|Independent assessment of Seal and trust boundaries                                       |F, L and W packages; G3 evidence           |Scope, method, findings, retests and residual risks; unresolved blocking controls prevent readiness approval                                               |
|H02 / QA-DevSecOps        |Repeatable load, availability, stop, recovery and restore exercises                       |Candidate build, approved isolated workload|Test matrix below with raw measurements, failure cases and hardware/workload description                                                                   |
|H03 / Incident coordinator|Active-compromise tabletop and evidence-preservation exercise                             |F06–F08, D09–D10                           |Assessment halt, restricted evidence, named owner notification and legal/CERT decision clock recorded; no autonomous regulatory filing assumed             |
|H04 / Service owner       |Candidate release package, admin/assessor/owner/reviewer guides, rollback and support rota|H01–H03, W05                               |Named on-call ownership, deployment rehearsal, restore/rollback rehearsal and known limitations accepted                                                   |
|H05 / Project Authority   |Combined PM Gate 4/software G4 readiness decision and explicit environment scope          |H01–H04                                    |Signed allow/hold decision; independent reviewer evidence; external pilot separately blocked unless regulatory, privacy and target permissions are recorded|

### Acceptance matrix

The thresholds below are **proposed baseline criteria derived from v1.3**. They are not confirmed results. Dataset size, workload duration, environmental assumptions and measurement exclusions require approval before testing.

|Test ID|Test / threshold from v1.3                                                                                           |Evidence method                                                                                                                                                |
|-------|---------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
|T01    |100% executed jobs linked to valid authorization; zero successful scope-bypass cases                                 |Reconcile executions to authorization/version/window; controlled expired/revoked/redirect/DNS/direct-egress negatives                                          |
|T02    |Zero successful cross-organization access in release suite                                                           |Tenant A/B fixtures on every API, worker, cache and export path                                                                                                |
|T03    |Stop new outbound requests within 5 seconds; workers terminate within 30 seconds, in every stop test                 |Independent boundary timestamps under the approved 10-job laboratory workload                                                                                  |
|T04    |At least 90% of selected seeded vulnerabilities detected                                                             |Pinned fixture set; true detections / eligible seeded findings; report misses and coverage                                                                     |
|T05    |At least 95% same-finding identity stability/correct aliases; zero silent distinct merges                            |Versioned mutation set and expected identities; report automatic and reviewer-assisted results separately                                                      |
|T06    |100% defined significant events recorded; evidence mutation and chain tampering detected                             |Event-type coverage and failure injection; independent anchor verification                                                                                     |
|T07    |100% closed high-risk findings contain verification evidence                                                         |Full population state/evidence audit; reject failed and incomplete verification                                                                                |
|T08    |No more than 5% assigned findings later invalidated                                                                  |Invalidated assigned findings / assigned findings in the defined cohort; record observation period and sample size. No assignments means not measurable, not 0%|
|T09    |Dispatch p95 <=30 seconds at 10 concurrent lab jobs; dashboard/API p95 <=2 seconds at 25 viewers and 100,000 findings|Predeclared duration, warm-up, request mix and hardware; retain raw latency and error data                                                                     |
|T10    |Worker failure detection <=30 seconds; safe fail/resume <=5 minutes                                                  |Kill/partition exercises, no duplicate actions and renewed scope validation                                                                                    |
|T11    |Queue/worker-service recovery <=15 minutes; zero loss of acknowledged audit events                                   |Restart/restore/partition scenarios, reconcile acknowledged IDs and chain heads; do not infer durability from a healthy-run test                               |
|T12    |Passive web <=60 minutes; source <=45; dependency <=30, or lower approved limit                                      |Profile-ceiling and termination tests; only selected software adapter applies                                                                                  |
|T13    |99.5% control-plane availability during approved pilot windows                                                       |Define denominator and planned window treatment before pilot; actual pilot monitoring, not a short laboratory success claim                                    |
|T14    |Privacy, safe-active allowlist, roles and incident controls pass approved cases                                      |Seeded secret detection, approved retention/hold/disposal tests, prohibited-class negatives and tabletop evidence                                              |

Numeric criteria are provisional targets. No cherry-picking or post hoc denominator changes are permitted. Security negative tests use owned controlled fixtures, not public targets.

## 9. Pilot, handover, closure and benefits

External pilot authorization is a **required approval packet**, not a confirmed approval. It must include: legal determination/required clarification and credential verification evidence specified by v1.3; approved PIA and processing terms; target ownership/permission; explicit methods/exclusions/time window; emergency contacts; incident escalation route; rate/profile limits; independent readiness decision; stop and rollback rehearsal; monitoring; and evidence-retention arrangements. Missing any mandatory entry yields **HOLD**. No regulatory deadline or licensing applicability is newly determined by this plan; qualified counsel is the accountable role for that workstream.

|ID / proposed owner role|Work to execute                                                                                                        |Acceptance / decision evidence                                                                                                                                 |
|------------------------|-----------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
|O01 / Service owner     |Conduct only the approved lab acceptance or separately authorized pilot; collect usability and operational measurements|Scope-specific report, actual metrics, incidents, false positives, limitations and signed acceptance; laboratory results clearly labeled                       |
|O02 / Service owner     |Handover deployments, access custody, backup/restore, updates, monitoring, support and disposal procedures             |Named recipients acknowledge readiness; privileged custody transfer tested; support and rollback ownership accepted; software G5/G6 evidence as applicable     |
|O03 / Project manager   |Reconcile delivered scope, costs, residual risks and open work; archive controlled records                             |PM Gate 6 closure decision by required authority; no unresolved item silently marked done; retention mapped to institutional schedule                          |
|O04 / Benefits owner    |Compare verified outcomes with an agreed baseline                                                                      |PM Gate 7 review: valid assignments, time to verified closure, recurrence, outstanding exposure and operational safety. Record coverage, cohort and limitations|

At handover, assign a named benefits owner and actual review dates. Proposed planning checkpoints are 30 days for stabilization and 90 days for initial benefits review, subject to the governing framework and Project Authority approval. These are proposed checkpoints, not confirmed institutional deadlines. If pilot authority is delayed, accept only a specifically authorized lab deliverable and keep operational benefits marked **Unconfirmed / Unmeasured**.

## 10. Shared gate evidence and task templates

Use one evidence index per candidate release and gate. Every entry contains artifact ID, requirement/test IDs, repository commit or document version, environment, tool/data versions, outcome, collector, collection time, integrity reference, reviewer and limitations. Store sensitive test evidence only through the approved evidence path.

Recommended repository locations once implementation is authorized:

- `docs/requirements/`: PRD, exclusions and requirement-to-test mapping.
- `docs/decisions/`: D01–D11 and architecture decisions.
- `docs/gates/`: signed decisions and evidence indexes, not duplicate evidence copies.
- `services/api/`, `services/worker/`, `adapters/`, `web/`: runtime components.
- `db/migrations/`, `infra/lab/`: tenant-aware schema and isolated laboratory deployment.
- `tests/unit/`, `tests/integration/`, `tests/safety/`, `tests/acceptance/`: positive and negative tests.
- `fixtures/synthetic/`, `docs/runbooks/`: reproducible seeds and operating procedures.

Task record:

```text
Task ID / title:
Baseline section and requirement IDs:
Proposed accountable role:
Named assignee / independent reviewer:
Assignment status: Proposed | Accepted | Declined | Reassign
Status: Blocked | Ready | In progress | Review | Verified
Entry decisions and dependencies:
Inputs / implementation scope / explicit exclusions:
Estimate and committed availability:
Acceptance test IDs and expected results:
Build or document version / environment:
Evidence references and limitations:
Reviewer decision and date:
```

Gate record:

```text
Seal phase / PM gate / software gate:
Candidate version and evidence index:
Required authority and named decision-makers:
Classification and authorized environment:
Approval status: Unconfirmed | Confirmed | Rejected | Superseded
Mandatory criteria: pass | fail | not evidenced
Open defects, residual risks and approved exceptions:
Decision: Proceed within stated scope | Hold | Rework
Explicitly prohibited next actions:
Conditions, owners, deadlines and expiry:
Signatures / date / next review:
```

Baseline traceability: F01–F08 derive from v1.3 §§8–9.1, 11–15; L01–L05 from §§4, 6.3–6.5, 6.10, 14–17; W01–W05 from §§6.6–6.9, 10 and Appendix A; H01–H05 and T01–T14 from §§11–13, 16–17 and Appendix B; O01–O04 from §§12.4, 15, 20–21 and the institutional gate alignment. New implementation failure semantics, repository layout and proposed post-handover checkpoints require review; they do not masquerade as text already approved in v1.3.

## 11. Immediate handoff and completion status

Prepared now: executive gate-readiness summary, phase-to-gate mapping, 11 decision records to complete, 23 engineering/workflow/hardening packages, four operational/benefits packages, 14 acceptance groups, dependency sequence and reusable task/gate evidence templates. These are **prepared planning artifacts**, not completed delivery work.

Confirmed document actions: owner adoption of v1.3 and owner-directed incorporation into v1.6. Formal institutional approvals remain unconfirmed.

Proposed assignments: D01–D11, F01–F08, L01–L05, W01–W05, H01–H05 and O01–O04, subject to named acceptance, capacity confirmation and dependency readiness.

Unconfirmed work and approvals: named appointments, formal gate signatures, legal determinations, capacity commitment, PRD approval, software implementation, external anchoring deployment, execution of tests, pilot authorization, operational acceptance, benefits measurement and production release.

Next executable action: assign D01–D11 and baseline the PRD and architecture under Phase 0. Until those assignments are accepted, the related tasks remain **Blocked**. Once the recorded exit and readiness conditions are met, submit the Phase 0 pack for the planned end-of-Weeks 1–4 PM Gate 2 / software G1 decision. Release F01–F08 into the approved delivery schedule only after a signed Proceed decision confirms scope, capacity, dependencies and prohibited next actions. This makes later stages assignable and testable without treating concept adoption as evidence of completed engineering or institutional gate approval.

## 12. Integrated upgrade traceability — v1.6

The controlling baseline is Seal Integrated Concept and Implementation Baseline v1.6, updated 7 September 2026. This plan retains original v1.3 section references as lineage; the section numbering remains valid. Confirmed document actions are owner adoption of v1.3 and the requested incorporation of v1.4 contracts and this plan. No additional institutional approvals are inferred. The readiness summary and proposed-assignment language from the latest saved plan are preserved.

| Requirement | Work packages | Acceptance groups | Additional scenario |
| --- | --- | --- | --- |
| U01 | F02, F04, F06 | T01, T10 | Per-request revocation and stale grants |
| U02 | F05, L02 | T01, T03, T14 | Independent egress and profile limits |
| U03 | L01, L02, L03, L05 | T04, T07 | Complete/partial/failed coverage |
| U04 | W03, F07 | T06, T07 | Correct revision, independent proof and receipt |
| U05 | L04, W02, W03 | T05, T07 | Recurrence, expiry and distinct dispositions |
| U06 | W01, W02 | T14 | Ordered tree, unknown/stale signals and overrides |
| U07 | F07, H02 | T06, T11 | Outbox, sink receipts and fail-closed admission |
| U08 | F08, H03 | T14 | Minimization, hold and disposal |
| U09 | F02, F03, W04 | T02, T14 | Trusted tenant context and pooled connections |
| U10 | F01, L01, L03 | T04, T05, T14 | Pinned versions and untrusted output admission |
| U11 | F06, F08, H03 | T03, T14 | Persistent halt and notification clock |
| U12 | F06, F07, H02 | T10, T11 | Lease/idempotency and safe restore |
| U13 | W04, W05, O04 | T08, T09, T13 | Coverage, denominators and aging |
| U14 | H01, H05, O02, O03 | T01–T14 | Evidence index and actual authority |

Candidate runtime policy values remain blocked pending D06/D10: one request/second, one in-flight request, 1 MiB response cap, 10-second timeout; EPSS threshold 0.10 and freshness 48 hours; Act acknowledgment four hours, Attend one business day, Track* five business days, Track next scheduled review. Remediation deadlines must be separately agreed. These are not legal deadlines. High/Critical closure requires verified anchor receipt; revocation and stop never wait for a sink receipt.


## 13. Closure of the v1.5 review — C01–C03

Updated 7 September 2026. The three corrections from the Seal Upgrade Proposal chat review at 15:14 UTC are incorporated into baseline v1.6 Appendix F and engineering specification v1.6 §13. C01–C03 are amendment tracking IDs. Design gaps are closed; tests and operational acceptance remain pending. Existing task assignments and gates are unchanged.

### C01 — Reject stale closure intents

Applies to U04/U05/U07, baseline §§6.8, 6.11 and 9.1, and W03/F07. This amendment governs finalization for every closure; High/Critical closure additionally requires its verified external anchor receipt.

Persist an immutable-by-version ClosureIntent containing intent ID, organization, target/control, finding ID and expected finding version, evidence-set revision and digest, repaired artifact revision, observation watermark, verification job/coverage/profile/rule versions, reviewer decision ID and closure-intent audit sequence/head. Retain superseded intents as history. A receipt must identify the exact intent and audit event; it cannot authorize a newer decision.

After independently verifying the receipt, finalize in one database transaction using a row lock or compare-and-swap against the expected finding version. Atomically require the current active intent, unchanged evidence revision, unchanged proof bindings, eligible verification state and no admitted contradictory or proof-invalidating observation after the recorded watermark. Commit Closed and its audit/outbox event together. Observation admission, evidence revision and closure finalization must share the same serialization boundary; checking in application memory before an unconditional write is insufficient.

Any new contradictory observation, replacement evidence, changed repaired revision, withdrawn reviewer decision or superseding intent invalidates the pending intent and increments the finding version. Reject a late receipt as stale; preserve it without closing the finding. Keep unresolved work visible and require fresh verification/review where needed. Duplicate receipts for the same already-finalized intent are idempotent no-ops. If contradiction is admitted after closure commits, reopen in a subsequent audited transaction. Stop or integrity restrictions still block finalization where the baseline requires them.

C01-A / T07,T06: delay a valid receipt, admit recurrence or replacement evidence, then deliver it: no closure. C01-B: race two intents and reordered/duplicate receipts: only the current eligible intent may finalize once. C01-C: force both serial orders of recurrence and finalization: contradiction either prevents closure or reopens it; no silent loss. C01-D: crash between receipt verification and commit: recovery repeats eligibility checks and cannot apply a stale decision. Evidence: database interleavings, row versions, audit events and receipt IDs. Acceptance awaits real integration tests.

### C02 — Stop active assessment when integrity becomes unavailable

Applies to U01/U02/U07/U12, baseline §§9.1, 11 and 13, and F05/F06/F07/H02. This extends the existing denial of new jobs and High/Critical closure to work already running.

Maintain an integrity-admission state and generation at the independent egress boundary. Signature failure, chain mismatch, failure to durably append required audit events, overdue anchor beyond fifteen minutes, or unavailable/stale integrity or revocation state makes it Untrusted. A briefly unavailable sink may remain within the existing anchor interval only while local durable auditing and trusted health remain available; receipt-dependent approvals and closures remain pending. Record the condition and detection time.

On Untrusted, revoke active execution grants and leases, deny every new outbound request, retry and lease/grant renewal, and stop running jobs. The egress boundary must consult trusted state or a bounded permit whose expiry cannot exceed the stop budget; workers cannot continue on cached approval. Prevent new outbound requests within five seconds of detection or loss of fresh state and terminate affected workers within thirty seconds. Already-transmitted requests cannot be recalled: abort open connections where possible, send no follow-up traffic and record residual exposure. These are provisional measured acceptance ceilings, not instantaneous-stop claims.

Preserve committed audit/evidence, restricted incident holds and stop/checkpoint state. Mark affected coverage Stopped/Partial or Failed with the cause, never Complete by default. If the primary audit path fails, use an approved restricted durable emergency journal under the existing privacy rules; do not acknowledge undurable events. Stop enforcement must not depend on successful journaling or anchoring. Reconcile the journal and external anchors under assurance review before restoring trust. Recovery needs an explicit authorized resume decision, a new integrity generation and fresh scope/revocation/profile/budget checks; restarting a service does not restart scans.

C02-A / T03,T06,T10,T11: with ten active lab jobs, inject each Untrusted trigger and measure egress requests, renewal/retry denials and termination against five/thirty seconds. C02-B: partition worker, policy or integrity state: cached grants expire within budget and direct egress stays denied. C02-C: restore services with queued retries: jobs stay stopped until explicit resume and renewed checks. C02-D: lose both sink and primary audit path: stop still works, no undurable acknowledgment, emergency records reconcile. Retain independent boundary timestamps, job coverage and recovery decisions. Acceptance awaits runtime evidence.

### C03 — Keep accepted and suppressed risks in exposure measures

Applies to U13, baseline §17 and Appendix D dashboard definitions, engineering §9, and W04/W05/O04. It replaces any wording that could exclude accepted or suppressed findings from the verified-closure denominator.

For a declared cohort and observation time, verified closure rate = currently verified Closed findings divided by all confirmed findings in that cohort. Risk accepted and Suppressed remain in the denominator and never enter the verified-Closed numerator. Reopened and Closure awaiting anchor also remain outside the numerator. An unresolved exposure count includes accepted and suppressed findings with separate visible disposition counts. Neither an override nor a change of display filter reduces exposure.

Declare cohort membership, period, scope, coverage and approved adjustment rules before reporting. Preserve initial and current denominator values and a reasoned adjustment log. A validated False positive may leave the confirmed cohort only under the predeclared reviewed correction rule; preserve the original observation and show the correction separately. Do not silently move exceptions to a new cohort. Expose both all-disposition totals and any explicitly labeled filtered view; never present a filtered view as the overall closure rate.

Worked acceptance fixture: ten confirmed findings comprise three verified Closed, two Risk accepted, one Suppressed and four other unresolved findings. Closure rate is 3/10 = 30%; unresolved exposure is seven, including the three accepted/suppressed findings. If one Closed finding recurs, the rate becomes 2/10 = 20% and unresolved exposure becomes eight. Changing an unresolved disposition to accepted or suppressed changes neither denominator nor closure numerator. Zero confirmed findings produces Not available, not 100%.

C03-A / T08,T13 plus W04/W05: reproduce the ten-finding fixture in API, dashboard and JSON/CSV, including recurrence. C03-B: apply disposition filters and verify the overall totals remain visible and unchanged. C03-C: approved false-positive correction emits a denominator adjustment and preserves history. C03-D: zero denominator is Not available. Evidence: fixed fixture IDs, query/filter definitions, before/after totals, export outputs and reviewer comparison; no operational benefit claim before measurement.

